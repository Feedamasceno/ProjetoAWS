import React from 'react';

function TestComponent() {
    return (
        <div>
            <h1>Teste de Botões</h1>
            <button>Editar</button>
            <button>Excluir</button>
        </div>
    );
}

export default TestComponent;